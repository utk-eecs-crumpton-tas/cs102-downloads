IS_LEAK_CHECK=false
SPLIT_LINE_ON='Enter a salary: $'
DOWNLOAD_URL='https://raw.githubusercontent.com/seeker-3/cs102-resources/main/tests/take-home-pay-calculator-tests.zip'
