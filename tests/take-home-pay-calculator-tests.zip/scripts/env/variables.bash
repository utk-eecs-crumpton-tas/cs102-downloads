IS_LEAK_CHECK=false
SPLIT_LINE_ON='Enter a salary: $'
DOWNLOAD_URL='https://raw.githubusercontent.com/utk-eecs-crumpton-tas/cs102-downloads/main/tests/take-home-pay-calculator-tests.zip'
