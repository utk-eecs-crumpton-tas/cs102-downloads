IS_LEAK_CHECK=false
SPLIT_LINE_ON='Enter city number: '
DOWNLOAD_URL='https://raw.githubusercontent.com/utk-eecs-crumpton-tas/cs102-downloads/main/tests/boiling-point-calculator-tests.zip'
