IS_LEAK_CHECK=false
SPLIT_LINE_ON='Enter city number: '
DOWNLOAD_URL='https://raw.githubusercontent.com/seeker-3/cs102-resources/main/tests/boiling-point-calculator-tests.zip'
