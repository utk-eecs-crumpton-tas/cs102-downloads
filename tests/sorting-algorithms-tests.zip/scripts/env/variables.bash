IS_LEAK_CHECK=false
SPLIT_LINE_ON='Type "i" for insertion sort, or "s" for selection sort: '
DOWNLOAD_URL='https://raw.githubusercontent.com/seeker-3/cs102-resources/main/tests/sorting-algorithms-tests.zip'
