IS_LEAK_CHECK=false
SPLIT_LINE_ON='Enter a 3 character airport code for (departure|arrival): '
DOWNLOAD_URL='https://raw.githubusercontent.com/utk-eecs-crumpton-tas/cs102-downloads/main/tests/airport-tests.zip'
