IS_LEAK_CHECK=true
SPLIT_LINE_ON='> '
DOWNLOAD_URL='https://raw.githubusercontent.com/utk-eecs-crumpton-tas/cs102-downloads/main/tests/multi-user-dungeon-tests.zip'
