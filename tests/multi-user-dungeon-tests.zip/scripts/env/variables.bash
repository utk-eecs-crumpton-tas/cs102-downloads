IS_LEAK_CHECK=true
SPLIT_LINE_ON='> '
DOWNLOAD_URL='https://raw.githubusercontent.com/seeker-3/cs102-resources/main/tests/multi-user-dungeon-tests.zip'
